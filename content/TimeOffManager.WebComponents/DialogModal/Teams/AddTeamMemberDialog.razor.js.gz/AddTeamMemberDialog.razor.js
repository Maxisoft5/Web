﻿export class AddTeamMemberDialog {
  
}

window.AddTeamMemberDialog = AddTeamMemberDialog;