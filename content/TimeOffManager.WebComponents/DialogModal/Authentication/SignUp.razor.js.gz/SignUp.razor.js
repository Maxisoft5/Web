﻿export class SignUp {
  
}

window.SignUp = SignUp;