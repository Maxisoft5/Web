﻿export class CompanyTimeOff {
  
}

window.CompanyTimeOff = CompanyTimeOff;