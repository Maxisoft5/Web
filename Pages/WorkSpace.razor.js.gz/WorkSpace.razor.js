﻿export class WorkSpace {
  
}

window.WorkSpace = WorkSpace;