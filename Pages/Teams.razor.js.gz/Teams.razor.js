﻿export class Teams {
  
}

window.Teams = Teams;