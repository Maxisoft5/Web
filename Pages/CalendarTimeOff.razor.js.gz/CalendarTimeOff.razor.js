﻿export class PersonalTimeOff {
  
}

window.PersonalTimeOff = PersonalTimeOff;