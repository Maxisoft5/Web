﻿export class AddTeamDialog {
  
}

window.AddTeamDialog = AddTeamDialog;